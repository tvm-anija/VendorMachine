﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace VendorMachineTest
{
    [TestClass]
    public class UserTest
    {
        private readonly UserRepository _primeService;

        public PrimeService_IsPrimeShould()
        {
            _primeService = new PrimeService();
        }

        [TestMethod]
        public void DeleteUser()
        {
            bool result = _primeService.IsPrime(1);

            Assert.IsFalse(result, "1 should not be prime");
        }
    }
}
